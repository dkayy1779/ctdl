﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace CTDLGT_BT2
{
    public class IntArray
    {
        private int [] arr;
        private int k { get; set; }
        private int x { get; set; }

        protected Random R = new Random();

        public IntArray() {}
        public IntArray(int k)
        {
            this.arr = new int [k];
        }

        public IntArray(int[] a)
        {

        }

        public IntArray(IntArray obj)
        {
            
        }

        public bool KiemTraKT(int n)
        {
            while(n < 1 || n > 200)
            {
                Console.Write("Vui long nhap lai: ");
                n = Convert.ToInt32(Console.ReadLine());
            }
            return false;
        }
        public void Nhap()
        {
            for(int i = 0; i < arr.Length; i++)
            {
                Console.Write($"Nhap phan tu thu a[{i}]: " );
                arr[i] = int.Parse(Console.ReadLine());
            }
        }

        public void Xuat()
        {
            Console.Write("Hien thi mang:");
            for(int i = 0; i < arr.Length; i++)
                Console.Write(arr[i] + " ");
        }

        public int TimTuanTu(int x)
        {
            int n = arr.Length;
            for(int i = 0; i < n; i++)
            {
                if(arr[i] == x)
                    return i;
            }
            return -1;
        }

        public int TimNhiPhan (int x)
        {
            int left, right, mid; left = 0; right = arr.Length - 1;
            do
            {
                mid = (left + right) / 2;
                if (arr[mid] == x)
                {
                    return mid;
                }
                else if (arr[mid] < x)
                {
                    left = mid + 1;
                }
                else if (arr[mid] > x)
                {
                    right = mid - 1;
                }
            }while (left <= right);
            return -1;
        }

        
    }
}
